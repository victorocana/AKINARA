package model;

/**
 * Representa un producto Otaku dentro del sistema.
 * Contiene información como nombre, categoría, precio, stock y descripción.
 */
public class ProductoOtaku {
	private int id;
	private String nombre;
	private String categoria;
	private double precio;
	private int stock;
	private String descripcion;

	/**
	 * Crea un nuevo producto Otaku con los datos básicos.
	 * La descripción se deja vacía por defecto hasta que se genere.
	 *
	 * @param id Identificador único del producto
	 * @param nombre Nombre del producto
	 * @param categoria Categoría a la que pertenece (ej: "Figuras", "Posters")
	 * @param precio Precio en euros
	 * @param stock Unidades disponibles en inventario
	 */
	public ProductoOtaku(int id, String nombre, String categoria, double precio, int stock) {
		this.id = id;
		this.nombre = nombre;
		this.categoria = categoria;
		this.precio = precio;
		this.stock = stock;
		this.descripcion = "";
	}

	/**
	 * @return ID único del producto
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id Nuevo ID del producto
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return Nombre del producto
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre Nuevo nombre del producto
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return Categoría del producto (ej: "Ropa", "Accesorios")
	 */
	public String getCategoria() {
		return categoria;
	}

	/**
	 * @param categoria Nueva categoría asignada al producto
	 */
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	/**
	 * @return Precio del producto en euros
	 */
	public double getPrecio() {
		return precio;
	}

	/**
	 * @param precio Nuevo precio en euros
	 */
	public void setPrecio(double precio) {
		this.precio = precio;
	}

	/**
	 * @return Unidades disponibles en inventario
	 */
	public int getStock() {
		return stock;
	}

	/**
	 * @param stock Nuevo valor de stock
	 */
	public void setStock(int stock) {
		this.stock = stock;
	}

	/**
	 * @return Descripción del producto (puede estar vacía si no se generó aún)
	 */
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * @param descripcion Descripción generada o escrita para el producto
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
}
