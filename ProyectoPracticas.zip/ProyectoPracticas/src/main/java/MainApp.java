// Importaciones necesarias para la aplicación
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import conexion.ProductoDAO;
import controller.LlmService;
import model.ProductoOtaku;
import view.InterfazConsola;

/**
 * Clase principal de la aplicación AkihabaraDB.
 * Gestiona productos otaku mediante una interfaz de consola, conexión a base de datos
 * y servicios de IA para generación de contenido.
 * 
 * @author CAMPUSFP Victor Ocaña
 */
public class MainApp {

    private InterfazConsola interfaz;
    private ProductoDAO productoDAO;
    private LlmService llmService;

    /**
     * Constructor de MainApp.
     * Establece la conexión con la base de datos, inicializa el DAO, la interfaz y el servicio de IA.
     * 
     * @throws SQLException si hay problemas de conexión con la base de datos
     * @throws Exception si ocurre un error general al inicializar componentes
     */
    public MainApp() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String usr = "root";
            String pwd = "campusfp";
            String url = "jdbc:mysql://localhost:3306/AkihabaraDB";
            Connection conn = DriverManager.getConnection(url, usr, pwd);

            this.productoDAO = new ProductoDAO(conn);
            this.llmService = new LlmService();
            this.interfaz = new InterfazConsola(productoDAO);

        } catch (SQLException e) {
            System.err.println("ERROR: No se pudo conectar a la base de datos.");
            e.printStackTrace();
            System.exit(1);
        } catch (Exception e) {
            System.err.println("ERROR: " + e.getMessage());
            System.exit(1);
        }
    }

    /**
     * Inicia el bucle principal de la aplicación, mostrando el menú y gestionando las opciones del usuario.
     */
    public void iniciar() {
        boolean salir = false;
        while (!salir) {
            try {
                interfaz.mostrarMenu();
                int opcion = interfaz.leerOpcion();

                switch (opcion) {
                    case 1:
                        gestionarProductos();
                        break;
                    case 2:
                        generarContenidoConIA();
                        break;
                    case 3:
                        salir = true;
                        interfaz.mostrarMensaje("Acabas de salir...");
                        break;
                    default:
                        interfaz.mostrarError("Opción invalida. Intenta de nuevo.");
                }
            } catch (Exception e) {
                interfaz.mostrarError("Error: " + e.getMessage());
            }
        }
    }

    /**
     * Gestiona el submenú de operaciones CRUD sobre productos.
     */
    private void gestionarProductos() {
        boolean volver = false;
        while (!volver) {
            interfaz.mostrarMenuGestionProductos();
            int opcion = interfaz.leerOpcion();
            switch (opcion) {
                case 1:
                    agregarProducto();
                    break;
                case 2:
                    buscarProducto();
                    break;
                case 3:
                    listarProductos();
                    break;
                case 4:
                    actualizarProducto();
                    break;
                case 5:
                    eliminarProducto();
                    break;
                case 6:
                    volver = true;
                    break;
                default:
                    interfaz.mostrarError("Opción no válida");
            }
        }
    }

    /**
     * Gestiona el submenú de generación de contenido con IA.
     */
    private void generarContenidoConIA() {
        boolean volver = false;
        while (!volver) {
            interfaz.mostrarMenuGeneracionContenido();
            int opcion = interfaz.leerOpcion();
            switch (opcion) {
                case 1:
                    generarDescripcionProductoConIA();
                    break;
                case 2:
                    sugerirCategoriaConIA();
                    break;
                case 3:
                    generarMultiplesDescripciones();
                    break;
                case 4:
                    volver = true;
                    break;
                default:
                    interfaz.mostrarError("Opción no válida");
            }
        }
    }

    /**
     * Agrega un nuevo producto solicitando los datos al usuario y generando la descripción automáticamente.
     */
    private void agregarProducto() {
        try {
            String nombre = interfaz.solicitarDato("Nombre del producto:");
            String sugerencia = llmService.sugerirCategoria(nombre);
            String categoria = interfaz.solicitarCategoria(sugerencia);
            double precio = interfaz.solicitarPrecio();
            int stock = interfaz.solicitarStock();

            String descripcion = llmService.generarDescripcionProducto(nombre, categoria, precio, stock);
            ProductoOtaku nuevoProducto = new ProductoOtaku(0, nombre, categoria, precio, stock);
            nuevoProducto.setDescripcion(descripcion);
            productoDAO.agregarProducto(nuevoProducto);

            interfaz.mostrarConfirmacion("Producto agregado con ID: " + nuevoProducto.getId());

            if (interfaz.confirmar("¿Desea generar una descripción automática para este producto?")) {
                generarYGuardarDescripcion(nuevoProducto.getId());
            }
        } catch (Exception e) {
            interfaz.mostrarError("Error al agregar: " + e.getMessage());
        }
    }

    /**
     * Solicita un ID al usuario y muestra el producto correspondiente.
     */
    private void buscarProducto() {
        try {
            int id = interfaz.solicitarIdProducto();
            ProductoOtaku producto = productoDAO.obtenerProductoPorId(id);
            if (producto != null) {
                interfaz.mostrarProducto(producto);
            } else {
                interfaz.mostrarError("Producto no encontrado");
            }
        } catch (Exception e) {
            interfaz.mostrarError("Error al buscar producto: " + e.getMessage());
        }
    }

    /**
     * Lista todos los productos almacenados en la base de datos.
     */
    private void listarProductos() {
        try {
            List<ProductoOtaku> productos = productoDAO.obtenerTodosLosProductos();
            interfaz.mostrarListaProductos(productos);
        } catch (Exception e) {
            interfaz.mostrarError("Error al listar productos: " + e.getMessage());
        }
    }

    /**
     * Actualiza los datos de un producto ya existente.
     */
    private void actualizarProducto() {
        try {
            int id = interfaz.solicitarIdProducto();
            ProductoOtaku producto = productoDAO.obtenerProductoPorId(id);

            if (producto != null) {
                interfaz.mostrarProducto(producto);

                String nuevoNombre = interfaz.solicitarDato("Nuevo nombre (" + producto.getNombre() + "):");
                double nuevoPrecio = interfaz.solicitarPrecio();
                String nuevaCategoria = interfaz.solicitarCategoria("Nueva categoría (" + producto.getCategoria() + "):");

                boolean cambios = !nuevoNombre.equals(producto.getNombre()) || !nuevaCategoria.equals(producto.getCategoria());

                producto.setNombre(nuevoNombre);
                producto.setPrecio(nuevoPrecio);
                producto.setCategoria(nuevaCategoria);

                productoDAO.actualizarProducto(producto);
                interfaz.mostrarConfirmacion("Producto actualizado");

                if (cambios && interfaz.confirmar("¿Regenerar descripción con los nuevos datos?")) {
                    generarYGuardarDescripcion(producto.getId());
                }
            } else {
                interfaz.mostrarError("Producto no encontrado");
            }
        } catch (Exception e) {
            interfaz.mostrarError("Error al actualizar producto: " + e.getMessage());
        }
    }

    /**
     * Elimina un producto según el ID proporcionado por el usuario.
     */
    private void eliminarProducto() {
        try {
            int id = interfaz.solicitarIdProducto();
            ProductoOtaku producto = productoDAO.obtenerProductoPorId(id);

            if (producto != null) {
                interfaz.mostrarProducto(producto);
                if (interfaz.confirmar("¿Está seguro que desea eliminar este producto?")) {
                    productoDAO.eliminarProducto(id);
                    interfaz.mostrarConfirmacion("Producto eliminado");
                }
            } else {
                interfaz.mostrarError("Producto no encontrado");
            }
        } catch (Exception e) {
            interfaz.mostrarError("Error al eliminar producto: " + e.getMessage());
        }
    }

    /**
     * Genera y guarda una nueva descripción para un producto específico utilizando IA.
     */
    private void generarDescripcionProductoConIA() {
        try {
            int id = interfaz.solicitarIdProducto();
            generarYGuardarDescripcion(id);
        } catch (Exception e) {
            interfaz.mostrarError("Error: " + e.getMessage());
        }
    }

    /**
     * Método auxiliar para generar y guardar una descripción para un producto.
     * 
     * @param idProducto ID del producto al que se le generará la descripción.
     * @throws Exception si el producto no existe o ocurre un error al procesar la IA.
     */
    private void generarYGuardarDescripcion(int idProducto) throws Exception {
        ProductoOtaku producto = productoDAO.obtenerProductoPorId(idProducto);
        if (producto == null)
            throw new Exception("Producto no encontrado");

        interfaz.mostrarMensaje("Creando descripción con Inteligencia Artificial...");

        CompletableFuture<String> futureDescripcion = llmService.generarDescripcionProductoAsync(
                producto.getNombre(), producto.getCategoria(), producto.getPrecio(), idProducto);

        while (!futureDescripcion.isDone()) {
            interfaz.mostrarAnimacionEspera();
            Thread.sleep(300);
        }

        String descripcion = futureDescripcion.get();
        interfaz.mostrarDescripcionGenerada(descripcion);

        if (interfaz.confirmar("¿Desea guardar la descripción generada en el producto?")) {
            producto.setDescripcion(descripcion);
            productoDAO.actualizarProducto(producto);
            interfaz.mostrarConfirmacion("Descripción guardada");
        }
    }

    /**
     * Sugiere una categoría usando IA a partir del nombre del producto ingresado por el usuario.
     */
    private void sugerirCategoriaConIA() {
        try {
            String nombreProducto = interfaz.solicitarDato("Ingrese el nombre del producto:");
            String categoriaSugerida = llmService.sugerirCategoria(nombreProducto);
            interfaz.mostrarSugerenciaCategoria(
                    "Para producto: " + nombreProducto + "\nCategoría sugerida: " + categoriaSugerida);
        } catch (Exception e) {
            interfaz.mostrarError("Error: " + e.getMessage());
        }
    }

    /**
     * Genera descripciones para todos los productos que no la tienen utilizando IA.
     */
    private void generarMultiplesDescripciones() {
        try {
            List<ProductoOtaku> productos = productoDAO.obtenerProductosSinDescripcion();

            if (productos.isEmpty()) {
                interfaz.mostrarMensaje("Todos los productos tienen descripción.");
                return;
            }

            interfaz.mostrarMensaje("Productos sin descripción: " + productos.size());

            if (interfaz.confirmar("¿Generar descripciones automáticas para todos?")) {
                int exitosos = 0;
                for (ProductoOtaku producto : productos) {
                    try {
                        String descripcion = llmService.generarDescripcionProducto(
                                producto.getNombre(), producto.getCategoria(), producto.getPrecio(), exitosos);
                        producto.setDescripcion(descripcion);
                        productoDAO.actualizarProducto(producto);
                        exitosos++;
                        interfaz.mostrarProgreso(exitosos, productos.size());
                    } finally {
                        // Recursos si es necesario
                    }
                }
                interfaz.mostrarConfirmacion("Descripciones generadas: " + exitosos + "/" + productos.size());
            }
        } catch (Exception e) {
            interfaz.mostrarError("Error: " + e.getMessage());
        }
    }

    /**
     * Método principal que lanza la aplicación.
     * 
     */
    public static void main(String[] args) {
        new MainApp().iniciar();
    }
}
