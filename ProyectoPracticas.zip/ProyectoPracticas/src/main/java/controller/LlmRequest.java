package controller;

import java.util.List;

public class LlmRequest {
    private String model;
    private double temperature;
    private List<LlmMessage> messages;

    public LlmRequest(String model, double temperature, List<LlmMessage> messages) {
        this.model = model;
        this.temperature = temperature;
        this.messages = messages;
    }

    public String getModel() {
        return model;
    }

    public double getTemperature() {
        return temperature;
    }

    public List<LlmMessage> getMessages() {
        return messages;
    }
}
