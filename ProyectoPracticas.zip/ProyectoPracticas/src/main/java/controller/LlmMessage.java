package controller;

public class LlmMessage {
    private String role;
    private String content;

    public String getRole() {
        return role != null ? role : "";  // Manejo de null
    }

    public String getContent() {
        return content != null ? content : "";  // Manejo de null
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setContent(String content) {
        this.content = content;
    }
}