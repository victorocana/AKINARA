package controller;

// Importación de librerías necesarias
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import com.google.gson.Gson;

public class LlmService {
	// URL de la API de OpenRouter
	private static final String OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions";
	// Modelo a utilizar
	private static final String MODEL = "mistralai/mistral-7b-instruct:free";
	// Tiempo de espera máximo para la petición
	private static final int TIMEOUT_SECONDS = 30;
	// Número máximo de reintentos si falla la petición
	private static final int MAX_RETRIES = 2;

	private String apiKey; // Clave de API para autenticarse
	private final HttpClient httpClient; // Cliente HTTP para hacer peticiones
	private final Gson gson; // Objeto Gson para convertir entre JSON y objetos Java

	// Constructor de la clase
	public LlmService() {
		// Obtiene la API Key desde la variable de entorno
		this.apiKey = System.getenv("OPENROUTER_API_KEY");

		// Si no está configurada, usa una clave por defecto (no recomendado en
		// producción)
		if (this.apiKey == null || this.apiKey.isEmpty()) {
			
			//AQUI DEBES INTRODUCIR TU API KEY
			this.apiKey = null;
		}

		// Verifica que la API key esté presente
		if (this.apiKey == null || this.apiKey.isEmpty()) {
			throw new IllegalStateException("OPENROUTER_API_KEY no está configurada.");
		}

		// Crea el cliente HTTP con tiempo de espera
		this.httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(TIMEOUT_SECONDS)).build();

		// Inicializa Gson
		this.gson = new Gson();
	}

	// Método sincrónico que genera una respuesta a partir de un prompt
	public String generarRespuesta(String prompt) {
		for (int intento = 0; intento <= MAX_RETRIES; intento++) {
			try {
				// Convierte la petición a JSON
				String body = gson.toJson(buildRequest(prompt));
				// Construye el request HTTP
				HttpRequest request = buildHttpRequest(body);
				// Envía el request
				HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
				// Procesa y retorna la respuesta
				return procesarRespuesta(response);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw new RuntimeException("Operación interrumpida", e);
			} catch (Exception e) {
				if (intento == MAX_RETRIES)
					throw new RuntimeException("Error tras varios intentos: " + e.getMessage(), e);
				try {
					// Espera antes de reintentar
					Thread.sleep(1000 * (intento + 1));
				} catch (InterruptedException ie) {
					Thread.currentThread().interrupt();
					throw new RuntimeException("Operación interrumpida", ie);
				}
			}
		}
		throw new RuntimeException("Error inesperado");
	}

	// Método asíncrono para generar una respuesta usando CompletableFuture
	public CompletableFuture<String> generarRespuestaAsync(String prompt) {
		String body = gson.toJson(buildRequest(prompt));
		HttpRequest request = buildHttpRequest(body);

		// Envia la petición de forma asíncrona y procesa la respuesta
		return httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApply(this::procesarRespuesta)
				.exceptionally(e -> {
					throw new RuntimeException("Error en la solicitud: " + e.getMessage(), e);
				});
	}

	// Construye el objeto de petición para el modelo de lenguaje
	private LlmRequest buildRequest(String prompt) {
		LlmMessage message = new LlmMessage(); // Aquí faltaría establecer el contenido del mensaje
		return new LlmRequest(MODEL, 0.7, List.of(message));
	}

	// Construye la petición HTTP con los encabezados necesarios
	private HttpRequest buildHttpRequest(String requestBody) {
		return HttpRequest.newBuilder().uri(URI.create(OPENROUTER_API_URL)).header("Authorization", "Bearer " + apiKey)
				.header("Content-Type", "application/json").header("HTTP-Referer", "https://akihabara-db.com")
				.header("X-Title", "AkihabaraDB").POST(HttpRequest.BodyPublishers.ofString(requestBody))
				.timeout(Duration.ofSeconds(TIMEOUT_SECONDS)).build();
	}

	// Procesa la respuesta de la API
	private String procesarRespuesta(HttpResponse<String> response) {
		if (response.statusCode() != 200) {
			String errorDetails = response.body() != null ? response.body() : "Sin detalles";
			throw new RuntimeException(
					"Error en la API. Código: " + response.statusCode() + ". Detalles: " + errorDetails);
		}

		// Transforma la resuesta de Json a un objeto de java
		LlmResponseMessage res = gson.fromJson(response.body(), LlmResponseMessage.class);
		if (res == null || res.getChoices().isEmpty()) {
			throw new RuntimeException("Respuesta de IA inválida o vacía");
		}

		// Toma el primer mensaje de la respuesta
		LlmChoice choice = res.getChoices().get(0);
		if (choice.getMessage() == null || choice.getMessage().getContent() == null) {
			throw new RuntimeException("Respuesta incompleta");
		}
// Devuelve únicamente el contenido
		return choice.getMessage().getContent().trim();
	}

	// Genera una descripción de producto a partir de sus datos
	public String generarDescripcionProducto(String nombre, String categoria, double precio, int stock) {
		String prompt = String.format(
				"Eres un redactor creativo experto en productos Otaku. Escribe una descripción original, única y en **español** "
						+ "para un producto de nuestra tienda AkihabaraDB.\n\n"
						+ "Nombre: %s\nCategoría: %s\nPrecio: %.2f€\nStock: %d unidades\n\n"
						+ "Incluye detalles llamativos, sin repetir plantillas, ni usar listas ni números, y que suene natural para un fan del anime.",
				nombre, categoria, precio, stock);
		return generarRespuesta(prompt);
	}

	// Versión asíncrona de la descripción de un producto
	public CompletableFuture<String> generarDescripcionProductoAsync(String nombre, String categoria, double precio,
			int stock) {
		String prompt = String.format(
				"Eres un redactor creativo experto en productos Otaku. Escribe una descripción original, única y en **español** "
						+ "para un producto de nuestra tienda AkihabaraDB.\n\n"
						+ "Nombre: %s\nCategoría: %s\nPrecio: %.2f€\nStock: %d unidades\n\n"
						+ "Incluye detalles llamativos, sin repetir plantillas, ni usar listas ni números, y que suene natural para un fan del anime.",
				nombre, categoria, precio, stock);
		return generarRespuestaAsync(prompt);
	}

	// Sugiere una categoría para un producto a partir de su nombre ingresado
	public String sugerirCategoria(String nombreProducto) {
		String prompt = "Sugiere una categoría adecuada para este producto Otaku: " + nombreProducto;
		return generarRespuesta(prompt);
	}
}
