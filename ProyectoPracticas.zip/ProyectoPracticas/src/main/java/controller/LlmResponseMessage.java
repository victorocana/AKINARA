package controller;

import java.util.List;

public class LlmResponseMessage {
    private List<LlmChoice> choices;  // Cambiado de Choice a LlmChoice

    public List<LlmChoice> getChoices() {
        return choices != null ? choices : List.of();  // Retorna lista vacía si es null
    }

    public void setChoices(List<LlmChoice> choices) {
        this.choices = choices;
    }
}