package controller;

public class LlmChoice {
    private LlmMessage message;  // Cambiado de Message a LlmMessage

    public LlmMessage getMessage() {
        return message;
    }

    public void setMessage(LlmMessage message) {
        this.message = message;
    }
}