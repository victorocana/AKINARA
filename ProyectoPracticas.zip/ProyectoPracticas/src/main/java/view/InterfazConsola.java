package view;

import conexion.ProductoDAO;
import model.ProductoOtaku;
import java.util.List;
import java.util.Scanner;

/**
 * Interfaz de consola para la gestión de productos Otaku.
 * Ofrece menús de navegación y facilita la interacción con el usuario.
 */
public class InterfazConsola {
	private Scanner scanner; // Lector de entradas por consola
	private ProductoDAO productoDAO; // Acceso a la base de datos

	/**
	 * Constructor de la interfaz.
	 *
	 * @param productoDAO DAO para operaciones sobre productos
	 */
	public InterfazConsola(ProductoDAO productoDAO) {
		this.scanner = new Scanner(System.in);
		this.setProductoDAO(productoDAO);
	}

	/**
	 * Muestra el menú principal del sistema.
	 */
	public void mostrarMenu() {
		System.out.println("\n=== AKIHABARA DB ===");
		System.out.println("1. Gestión de Productos");
		System.out.println("2. Generación de Contenido con IA");
		System.out.println("3. Salir");
		System.out.print("Seleccione una opción: ");
	}

	/**
	 * Muestra el menú de gestión CRUD de productos.
	 */
	public void mostrarMenuGestionProductos() {
		System.out.println("\n--- GESTIÓN DE PRODUCTOS ---");
		System.out.println("1. Agregar producto");
		System.out.println("2. Buscar producto por ID");
		System.out.println("3. Listar todos los productos");
		System.out.println("4. Actualizar producto");
		System.out.println("5. Eliminar producto");
		System.out.println("6. Volver al menú principal");
		System.out.print("Seleccione una opción: ");
	}

	/**
	 * Muestra el menú para acciones con inteligencia artificial.
	 */
	public void mostrarMenuGeneracionContenido() {
		System.out.println("\n--- GENERACIÓN DE CONTENIDO CON IA ---");
		System.out.println("1. Generar descripción para producto");
		System.out.println("2. Sugerir categoría para producto");
		System.out.println("3. Generar descripciones para productos sin descripción");
		System.out.println("4. Volver al menú principal");
		System.out.print("Seleccione una opción: ");
	}

	/**
	 * Solicita una opción numérica al usuario.
	 *
	 * @return La opción seleccionada
	 */
	public int leerOpcion() {
		while (!scanner.hasNextInt()) {
			System.out.print("Entrada inválida. Ingrese un número: ");
			scanner.next();
		}
		return scanner.nextInt();
	}

	/**
	 * Solicita un dato textual al usuario.
	 *
	 * @param mensaje Texto que se muestra como prompt
	 * @return Texto ingresado por el usuario
	 */
	public String solicitarDato(String mensaje) {
		System.out.print(mensaje + " ");
		scanner.nextLine();
		return scanner.nextLine();
	}

	/**
	 * Solicita un precio válido.
	 *
	 * @return Precio ingresado
	 */
	public double solicitarPrecio() {
		System.out.print("Ingrese el precio del producto: ");
		while (!scanner.hasNextDouble()) {
			System.out.print("Precio inválido. Ingrese un número: ");
			scanner.next();
		}
		return scanner.nextDouble();
	}

	/**
	 * Sugiere una categoría y permite editarla.
	 *
	 * @param sugerencia Categoría propuesta por IA
	 * @return Categoría final aceptada por el usuario
	 */
	public String solicitarCategoria(String sugerencia) {
		System.out.println("Categoría sugerida: " + sugerencia);
		System.out.print("Ingrese la categoría (presione Enter para aceptar la sugerencia): ");
		scanner.nextLine();
		String input = scanner.nextLine();

		String categoriaFinal = input.isEmpty() ? sugerencia : input;
		if (categoriaFinal.length() > 100) {
			System.out.println("Categoría muy larga, se acorta.");
			categoriaFinal = categoriaFinal.substring(0, 50);
		}
		return categoriaFinal;
	}

	/**
	 * Muestra los detalles completos de un producto.
	 *
	 * @param producto Producto a mostrar
	 */
	public void mostrarProducto(ProductoOtaku producto) {
		System.out.println("\n--- DETALLES DEL PRODUCTO ---");
		System.out.println("ID: " + producto.getId());
		System.out.println("Nombre: " + producto.getNombre());
		System.out.println("Categoría: " + producto.getCategoria());
		System.out.println("Precio: " + producto.getPrecio());
		System.out.println("Stock: " + producto.getStock());
		if (producto.getDescripcion() != null && !producto.getDescripcion().isEmpty()) {
			System.out.println("Descripción: " + producto.getDescripcion());
		}
	}

	/**
	 * Muestra un listado con todos los productos registrados.
	 *
	 * @param productos Lista de productos
	 */
	public void mostrarListaProductos(List<ProductoOtaku> productos) {
		System.out.println("\n--- LISTADO DE PRODUCTOS ---");
		if (productos.isEmpty()) {
			System.out.println("No hay productos registrados.");
			return;
		}

		System.out.printf("%-5s %-30s %-15s %-10s %-5s%n", "ID", "Nombre", "Categoría", "Precio", "Stock");
		System.out.println("------------------------------------------------------------");
		for (ProductoOtaku p : productos) {
			System.out.printf("%-5d %-30s %-15s %-10.2f %-5d%n", p.getId(), p.getNombre(), p.getCategoria(),
					p.getPrecio(), p.getStock());
		}
	}

	/**
	 * Muestra un mensaje informativo.
	 *
	 * @param mensaje Mensaje a mostrar
	 */
	public void mostrarMensaje(String mensaje) {
		System.out.println("\n> " + mensaje);
	}

	/**
	 * Muestra un mensaje de error en rojo.
	 *
	 * @param error Texto del error
	 */
	public void mostrarError(String error) {
		System.err.println("\nERROR: " + error);
	}

	/**
	 * Muestra una confirmación al usuario.
	 *
	 * @param mensaje Mensaje de confirmación
	 */
	public void mostrarConfirmacion(String mensaje) {
		System.out.println("\n " + mensaje);
	}

	/**
	 * Pregunta al usuario si desea continuar con una acción.
	 *
	 * @param pregunta Pregunta formulada
	 * @return true si el usuario responde "si"
	 */
	public boolean confirmar(String pregunta) {
		System.out.print("\n" + pregunta + " (SI/NO): ");
		String respuesta = scanner.next().toLowerCase();
		return respuesta.equals("si");
	}

	/**
	 * Muestra una animación simple (por ejemplo, al esperar respuesta IA).
	 */
	public void mostrarAnimacionEspera() {
		System.out.print(".");
	}

	/**
	 * Muestra una descripción generada por IA.
	 *
	 * @param descripcion Texto generado
	 */
	public void mostrarDescripcionGenerada(String descripcion) {
		System.out.println("\n--- DESCRIPCIÓN GENERADA ---");
		System.out.println(descripcion);
	}

	/**
	 * Muestra una categoría sugerida por IA.
	 *
	 * @param mensaje Texto de la sugerencia
	 */
	public void mostrarSugerenciaCategoria(String mensaje) {
		System.out.println("\n--- SUGERENCIA DE CATEGORÍA ---");
		System.out.println(mensaje);
	}

	/**
	 * Muestra el progreso de una tarea en porcentaje.
	 *
	 * @param actual Progreso actual
	 * @param total Total a alcanzar
	 */
	public void mostrarProgreso(int actual, int total) {
		System.out.printf("Progreso: %d/%d (%.0f%%)%n", actual, total, (actual * 100.0 / total));
	}

	/**
	 * Solicita un ID numérico válido.
	 *
	 * @return ID ingresado
	 */
	public int solicitarIdProducto() {
		System.out.print("Ingrese el ID del producto: ");
		while (!scanner.hasNextInt()) {
			System.out.print("ID inválido. Ingrese un número: ");
			scanner.next();
		}
		return scanner.nextInt();
	}

	/**
	 * Obtiene el DAO utilizado por esta interfaz.
	 *
	 * @return DAO de productos
	 */
	public ProductoDAO getProductoDAO() {
		return productoDAO;
	}

	/**
	 * Establece el DAO para acceder a la base de datos.
	 *
	 * @param productoDAO DAO a utilizar
	 */
	public void setProductoDAO(ProductoDAO productoDAO) {
		this.productoDAO = productoDAO;
	}

	/**
	 * Solicita un valor de stock numérico válido.
	 *
	 * @return Stock ingresado
	 */
	public int solicitarStock() {
		System.out.print("Ingrese el Stock del producto: ");
		while (!scanner.hasNextInt()) {
			System.out.print("Stock inválido. Ingrese un número: ");
			scanner.next();
		}
		return scanner.nextInt();
	}
}
