package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import conexion.ProductoDAO;
import model.ProductoOtaku;

public class SetupDatos {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String usr = "root";
			String pwd = "campusfp";
			String url = "jdbc:mysql://localhost:3306/AkihabaraDB?serverTimezone=UTC";

			Connection conn = DriverManager.getConnection(url, usr, pwd);

			ProductoDAO productoDAO = new ProductoDAO(conn);

			List<ProductoOtaku> productos = productoDAO.obtenerTodosLosProductos();

			if (productos.isEmpty()) {
				ProductoOtaku producto1 = new ProductoOtaku(0, "Figura de Anya Forger", "Figura", 59.95, 8);
				ProductoOtaku producto2 = new ProductoOtaku(0, "Manga Chainsaw Man Vol.1", "Manga", 9.99, 20);
				ProductoOtaku producto3 = new ProductoOtaku(0, "Póster Studio Ghibli Colección", "Póster", 15.50, 15);
				ProductoOtaku producto4 = new ProductoOtaku(0, "Funko Pop! Naruto Hokage", "Figura", 25.99, 12);
				ProductoOtaku producto5 = new ProductoOtaku(0, "Sudadera Attack on Titan", "Ropa", 39.99, 5);

				productoDAO.agregarProducto(producto1);
				productoDAO.agregarProducto(producto2);
				productoDAO.agregarProducto(producto3);
				productoDAO.agregarProducto(producto4);
				productoDAO.agregarProducto(producto5);

				System.out.println("Base de datos inicializada con datos de ejemplo");
			} else {
				System.out.println("La base de datos ya contiene datos");
			}

			System.out.println("\nListado de productos:");
			for (ProductoOtaku p : productoDAO.obtenerTodosLosProductos()) {
				System.out.printf("ID: %d, Nombre: %s, Categoría: %s, Precio: %.2f, Stock: %d, Descripción: %s%n",
						p.getId(), p.getNombre(), p.getCategoria(), p.getPrecio(), p.getStock(), p.getDescripcion());
			}

			conn.close();
		} catch (ClassNotFoundException e) {
			System.err.println("Error al cargar el driver JDBC: " + e.getMessage());
		} catch (SQLException e) {
			System.err.println("Error al conectar con la base de datos: " + e.getMessage());
			e.printStackTrace();
		}
	}
}
