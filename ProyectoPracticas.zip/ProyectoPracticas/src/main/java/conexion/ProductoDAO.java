package conexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.ProductoOtaku;

/**
 * Clase DAO gestiona las operaciones CRUD sobre la tabla de productos.
 * Se conecta a una base de datos MySQL para operar en la tablaproductos.
 * 
 * @author CAMPUSFP
 */
public class ProductoDAO {
    private final Connection conexion; // Conexión activa a la base de datos

    /**
     * Crea un nuevo DAO utilizando una conexión de base de datos existente.
     *
     * @param conexion Objeto Connection con la base de datos
     */
    public ProductoDAO(Connection conexion) {
        this.conexion = conexion;
    }

    /**
     * Inserta un nuevo producto en la base de datos. Actualiza el ID del objeto producto con la clave generada.
     *
     * @param producto ProductoOtaku a insertar
     * @throws SQLException si ocurre un error de base de datos
     */
    public void agregarProducto(ProductoOtaku producto) throws SQLException {
        String sql = "INSERT INTO productos (nombre, categoria, precio, stock, descripcion) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conexion.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, producto.getNombre());
            ps.setString(2, producto.getCategoria());
            ps.setDouble(3, producto.getPrecio());
            ps.setInt(4, producto.getStock());
            ps.setString(5, producto.getDescripcion() != null ? producto.getDescripcion() : "");

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    producto.setId(rs.getInt(1));
                }
            }
        }
    }

    /**
     * Recupera un producto por su ID.
     *
     * @param id Identificador único del producto
     * @return ProductoOtaku si existe; null si no se encuentra
     * @throws SQLException si ocurre un error de base de datos
     */
    public ProductoOtaku obtenerProductoPorId(int id) throws SQLException {
        String sql = "SELECT * FROM productos WHERE id = ?";
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearProducto(rs);
                }
            }
        }
        return null;
    }

    /**
     * Obtiene todos los productos registrados en la base de datos.
     *
     * @return Lista de productos existentes
     * @throws SQLException si ocurre un error de base de datos
     */
    public List<ProductoOtaku> obtenerTodosLosProductos() throws SQLException {
        List<ProductoOtaku> productos = new ArrayList<>();
        String sql = "SELECT * FROM productos ORDER BY id";
        try (Statement st = conexion.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                productos.add(mapearProducto(rs));
            }
        }
        return productos;
    }

    /**
     * Recupera todos los productos que no tienen descripción.
     *
     * @return Lista de productos sin descripción
     * @throws SQLException si ocurre un error de base de datos
     */
    public List<ProductoOtaku> obtenerProductosSinDescripcion() throws SQLException {
        List<ProductoOtaku> productos = new ArrayList<>();
        String sql = "SELECT * FROM productos WHERE descripcion IS NULL OR descripcion = ''";
        try (Statement st = conexion.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                productos.add(mapearProducto(rs));
            }
        }
        return productos;
    }

    /**
     * Actualiza los datos de un producto existente.
     *
     * @param producto Objeto ProductoOtaku con los nuevos datos
     * @throws SQLException si ocurre un error de base de datos
     */
    public void actualizarProducto(ProductoOtaku producto) throws SQLException {
        String sql = "UPDATE productos SET nombre=?, categoria=?, precio=?, stock=?, descripcion=? WHERE id=?";
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, producto.getNombre());
            ps.setString(2, producto.getCategoria());
            ps.setDouble(3, producto.getPrecio());
            ps.setInt(4, producto.getStock());
            ps.setString(5, producto.getDescripcion() != null ? producto.getDescripcion() : "");
            ps.setInt(6, producto.getId());
            ps.executeUpdate();
        }
    }

    /**
     * Elimina un producto de la base de datos a partir de su ID.
     *
     * @param id Identificador único del producto a eliminar
     * @throws SQLException si ocurre un error de base de datos
     */
    public void eliminarProducto(int id) throws SQLException {
        String sql = "DELETE FROM productos WHERE id=?";
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    /**
     * Convierte un ResultSet de SQL en un objeto ProductoOtaku.
     *
     * @param rs ResultSet con los datos de un producto
     * @return Objeto ProductoOtaku mapeado
     * @throws SQLException si ocurre un error al leer el ResultSet
     */
    private ProductoOtaku mapearProducto(ResultSet rs) throws SQLException {
        ProductoOtaku producto = new ProductoOtaku(
            rs.getInt("id"),
            rs.getString("nombre"),
            rs.getString("categoria"),
            rs.getDouble("precio"),
            rs.getInt("stock")
        );
        producto.setDescripcion(rs.getString("descripcion"));
        return producto;
    }
}
