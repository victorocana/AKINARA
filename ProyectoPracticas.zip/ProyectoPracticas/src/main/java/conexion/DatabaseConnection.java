package conexion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private Connection conexion;

    public DatabaseConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        String usr = "root";
        String pwd = "campusfp";
        String url = "jdbc:mysql://localhost:3306/AkihabaraDB";

        this.conexion = DriverManager.getConnection(url, usr, pwd);
    }

    public Connection getConnection() {
        return conexion;
    }

    public void closeConnection() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
            }
        } catch (SQLException e) {
            System.err.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }
}
