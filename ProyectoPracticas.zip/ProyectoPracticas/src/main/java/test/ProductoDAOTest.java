package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ProductoDAOTest {
	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/AkihabaraDB?useSSL=false&serverTimezone=UTC";
		String usuario = "root";
		String password = "campusfp";

		try (Connection conn = DriverManager.getConnection(url, usuario, password)) {
			System.out.println("Conexión exitosa!");
		} catch (SQLException e) {
			System.err.println("Error al conectar: " + e.getMessage());
			e.printStackTrace();
		}
	}
}
